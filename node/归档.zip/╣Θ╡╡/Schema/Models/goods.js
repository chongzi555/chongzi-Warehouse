const { db } = require('../Schema/config');

const GoodsSchema= require('../Schema/goods');

const Goods = db.model('goods', GoodsSchema); // User可操作数据库。

module.exports = Goods; // 导出