const Router = require('koa-router')
const user = require('../control/user')
const diary = require('../control/diary')

const chapter = require('../control/chapter');
const course = require('../control/course');
const subject = require('../control/subject')
const audioChapter = require('../control/audioChapter');
const parentingChapter = require('../control/parentingChapter');
const parentingSubject = require('../control/parentingSubject');
const audio = require('../control/audio');
const ranking = require('../control/ranking');

const upload = require('../util/upload')
const avatar = require('../util/avatar')
const comment = require('../control/comment')
const reply = require('../control/reply')
const good = require('../control/good')

const router = new Router

// 首页，用户是否还在登录时间。是，自动登录
router.get('/',user.keepLog,user.islogin);

// 注册用户 路由
router.post('/user/reg', user.reg);

// 登录
router.post('/user/login', user.login);

// 返回用户名路由
router.get('/username',user.keepLog,user.username);

// 注销
router.get('/user/logout',user.logout);

// 日记本
router.get('/user/book/:page',user.keepLog,user.book);

// 个人中心 -> 该用户是否有message
router.get('/user/message',user.keepLog,user.message);

// 用户列表
router.get('/user/list/:page',user.keepLog,user.list);
// 用户排行榜
router.get('/user/rankings/:page',user.keepLog,user.rankings);
// 修改用户信息
router.put('/user/changeUserInfo',user.keepLog,user.changeUserInfo);

// 个人中心 -> 用户删除
router.delete('/user/delete/:id',user.keepLog,user.delete);

// 日记 banner
router.get('/diary/banner',user.keepLog,diary.banner);

// 日记 type
router.get('/diary/type/:type',user.keepLog,diary.type);

// 日记 index see
router.get('/diary/indexsee',user.keepLog,diary.indexSee);

// 日记 index good
router.get('/diary/indexgood',user.keepLog,diary.indexGood);

// 日记 index new
router.get('/diary/indexnew',user.keepLog,diary.indexNew);

// 增加章节；
router.post('/chapter/add',user.keepLog,chapter.add);
// 增加课程；
router.post('/course/add',user.keepLog,course.add);
// 增加题目；
router.post('/subject/add',user.keepLog,subject.add);
// 增加audio章节；
router.post('/audioChapter/add',user.keepLog,audioChapter.add);
// 增加音频；
router.post('/audio/add',user.keepLog,audio.add);
// 增加亲子竞技章节；
router.post('/parentingChapter/add',user.keepLog,parentingChapter.add);
// 增加亲子竞技列表；
router.post('/parentingSubject/add',user.keepLog,parentingSubject.add);
// 增加排位赛题目；
router.post('/ranking/add',user.keepLog,ranking.add);

// 章节列表
router.get('/chapter/list/:page',user.keepLog,chapter.list);
// 课程列表
router.get('/course/list/:page/:id',user.keepLog,course.list);
// 题目列表
router.get('/subject/list/:page/:id/:chapterId',user.keepLog,subject.list);
// 音频章节列表
router.get('/audioChapter/list/:page',user.keepLog,audioChapter.list);
// 章节下音频列表
router.get('/audio/list/:page/:id',user.keepLog,audio.list);
// 亲子章节列表
router.get('/parentingChapter/list/:page',user.keepLog,parentingChapter.list);
// 亲子章节下的题目
router.get('/parentingSubject/list/:page/:id',user.keepLog,parentingSubject.list);
// 排位赛题目
router.get('/ranking/list/:page/:id',user.keepLog,ranking.list);

// 个人日记
router.get('/diary/my/:page/:id',user.keepLog,diary.my);

// 个人日记 de 最近点赞和评论
router.get('/diary/myrecently/:id',user.keepLog,diary.myrecently);

// 私密日记
router.get('/diary/private/:page',user.keepLog,diary.private);

// 日记详情
router.get('/diary/details/:id',user.keepLog,diary.details);

// 日记浏览排行 rankings
router.get('/diary/rankings/:page',user.keepLog,diary.rankings);

// 章节 delete
router.delete('/chapter/delete/:id',user.keepLog,chapter.delete);
// 课程 delete
router.delete('/course/delete/:id',user.keepLog,course.delete);
// 题目 delete
router.delete('/subject/delete/:id',user.keepLog,subject.delete);
// 音频章节 delete
router.delete('/audioChapter/delete/:id',user.keepLog,audioChapter.delete);
// 音频列表 delete
router.delete('/audio/delete/:id',user.keepLog,audio.delete);
// 亲子章节 delete
router.delete('/parentingChapter/delete/:id',user.keepLog,parentingChapter.delete);
// 亲子章节下的题目 delete
router.delete('/parentingSubject/delete/:id',user.keepLog,parentingSubject.delete);
// 排位赛下的题目 delete
router.delete('/ranking/delete/:id',user.keepLog,ranking.delete);

// 日记 search
router.get('/diary/search/:type/:input/:page',user.keepLog,diary.search);

// see
router.put('/diary/view',user.keepLog,diary.see);

// see
router.get('/diary/all/:page',user.keepLog,diary.all);

// comment add
router.post('/comment/add',user.keepLog,comment.add);

// comment diary_list   对应日记的评论列表
router.get('/comment/diary_list/:id',user.keepLog,comment.diary_list);

// comment list
router.get('/comment/list/:page',user.keepLog,comment.list);

// comment 评论 message
router.get('/comment/message/:id',user.keepLog,comment.message);

// comment 评论 message
router.delete('/comment/message/:id',user.keepLog,comment.messageDel);

// comment_good add
router.post('/comment_good/add',user.keepLog,comment.goodAdd);

// comment_good add
router.delete('/comment_good/delete/:id',user.keepLog,comment.goodDelete);

// comment_good list
router.get('/comment_good/list/:id',user.keepLog,comment.goodList);

// comment delete
router.delete('/comment/delete/:id',user.keepLog,comment.delete);

// reply add
router.post('/reply/add',user.keepLog,reply.add);

// reply list
router.get('/reply/list/:id',user.keepLog,reply.list);

// reply other
router.post('/reply/other',user.keepLog,reply.other);

// good 点赞日记
router.post('/gooddiary/add',user.keepLog,good.add);

// good 用户是否已经点赞了。
router.get('/gooddiary/good/:id',user.keepLog,good.isgood);

// good 取消点赞
router.delete('/gooddiary/reduce/:id',user.keepLog,good.reduce);

// good 点赞列表
router.get('/gooddiary/list/:id',user.keepLog,good.list);

// good 点赞 message
router.get('/good/message/:id',user.keepLog,good.message);

// good 点赞 message
router.delete('/good/message/:id',user.keepLog,good.messageDel);

// 上传头像
router.post("/user/avatar/:id",user.keepLog,avatar.upload.single("file",20),avatar.avatar);

// 上传图片
router.post("/upload",user.keepLog,upload.upload.array("file",20),upload.photo);

module.exports = router
