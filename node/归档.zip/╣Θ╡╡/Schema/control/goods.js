const Diary = require('../Models/diary')
const User = require('../Models/user')
const Good = require('../Models/good_diary')
const Comment = require('../Models/comment')

exports.banner = async ctx => {
  const data = await Diary.find({banner:1})
  ctx.body = data;
};

exports.indexSee = async ctx =>{
  const data = await Diary
    .find({ispublic:1})
    .sort('-see')
    .limit(5)
  ctx.body = data;
};

exports.type = async ctx => {
  let type = ctx.params.type;
  let arr = ['回收','共享','转卖'];
  const data = await Diary
    .find({ispublic:1,type:arr[type]})
    .limit(8)
    .populate('from','username')
  ctx.body = data;
};

exports.add = async ctx => {
  let data
  if(!ctx.session.uid){
    data = 0;
  }else{
    let bodyData = ctx.request.body;
    bodyData.from = ctx.session.uid;
    data = await new Diary(bodyData)
      .save()
      .then(res=>res);
    await User.updateOne({_id:data.from},{$inc:{diaryNum:1}});
  }
  ctx.body = data;
};

exports.list = async ctx => {
  let uid = ctx.session.uid;
  let page = ctx.params.page;
  page--;
  let query;
  if(ctx.session.username === 'admin'){
    query = {};
  }else{
    query = {from:uid};
  }
  const data = await Diary
    .find(query)
    .sort('-created')
    .skip(page*10)
    .limit(10)
    .populate('from','username'); // 关联，那个字段，需要拿到什么数据，若要多个，则在username _id这样写。(有空格)
  const total = await Diary.find(query);
  ctx.body = {
    data,
    total:total.length,
  };
};

exports.myrecently = async ctx => {
  let id = ctx.params.id;
  let uid = ctx.session.uid;
  if(id === '0'){
    id = uid;
  }
  const good = await Good
    .find({author:id})
    .sort('-created')
    .limit(5)
    .populate('diary','title')
  console.log(good)
  const comment = await Comment
    .find({author:id})
    .sort('-created')
    .limit(5)
    .populate('diary','title')
  ctx.body = {
    good,
    comment,
  }
};

exports.details = async ctx => {
  let _id = ctx.params.id;
  const data = await Diary
    .findById(_id)
    .populate('from','username _id avatar');
  ctx.body = data;
};

exports.see = async ctx => {
  let data = 1;
  if(!ctx.session.uid){
    data = 0;
  }else{
    let _id = ctx.request.body._id;
    Diary.updateOne({_id},{$inc:{see:1}}).exec();
  }
  ctx.body = data;
};
